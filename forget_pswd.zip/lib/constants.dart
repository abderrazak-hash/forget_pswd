import 'package:flutter/material.dart';

Color mainClr = const Color(0xFF024D6D);
